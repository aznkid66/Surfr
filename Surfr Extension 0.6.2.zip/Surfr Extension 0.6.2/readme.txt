Installation instructions:

1. Download and install Google Chrome
2. Open Chrome and go to chrome://extensions
3. Check "Developer mode"
4. Click the button labeled "Load unpacked extension..."
5. Select this folder (Surfr Extension 0.6.2)

WARNING: DISABLE/UNINSTALL THIS EXTENSION BEFORE DOING SENSITIVE WEB BROWSING

Uninstallation instructions:

1. Open Chrome and go to chrome://extensions
3. Click the Trash Bin icon to the right of Surfr Extension's block